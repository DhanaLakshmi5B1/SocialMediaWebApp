const router = require("express").Router();
const Post = require("../models/Post");

// ✅ CREATE POST
router.post("/", async (req, res) => {
  try {
    const newPost = new Post({
      user: req.body.userId,
      content: req.body.content,
    });

    const savedPost = await newPost.save();
    res.status(201).json(savedPost);
  } catch (err) {
    console.error("POST SAVE ERROR:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ LIKE / UNLIKE
router.put("/like/:id", async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post.likes.includes(req.body.userId)) {
      await post.updateOne({ $push: { likes: req.body.userId } });
      res.status(200).json("Post Liked");
    } else {
      await post.updateOne({ $pull: { likes: req.body.userId } });
      res.status(200).json("Post Unliked");
    }
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;