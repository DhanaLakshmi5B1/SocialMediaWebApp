const router = require("express").Router();
const User = require("../models/User");
const bcrypt = require("bcryptjs");

// ================= REGISTER USER =================
router.post("/register", async (req, res) => {
  try {
    console.log("🔥 Incoming register request:", req.body);

    const { username, email, password } = req.body;

    // Validation
    if (!username || !email || !password) {
      console.log("❌ Validation failed");
      return res.status(400).json({ message: "All fields required" });
    }

    // Check existing user
    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      console.log("❌ User already exists:", existingUser);
      return res.status(400).json({ message: "Email or Username already exists" });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Save user
    const newUser = new User({ username, email, password: hashedPassword });
    const savedUser = await newUser.save();

    // Remove password from response
    const { password: _, ...userData } = savedUser._doc;

    console.log("✅ User registered successfully:", userData);
    res.status(201).json(userData);

  } catch (err) {
    console.error("🔥 USER SAVE ERROR:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;