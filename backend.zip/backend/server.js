const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");

dotenv.config();

const app = express();

// ================= MIDDLEWARES =================
app.use(cors());
app.use(express.json());

// ================= ROUTES =================
const userRouter = require("./routes/userRouter");
// If you add posts/comments later
const postRouter = require("./routes/postRouter");
const commentRouter = require("./routes/commentRouter");

app.use("/api/users", userRouter);
 app.use("/api/posts", postRouter);
 app.use("/api/comments", commentRouter);

// ================= TEST ROUTE =================
app.get("/test", async (req, res) => {
  try {
    res.send("✅ Backend and MongoDB are reachable!");
  } catch (err) {
    res.status(500).json({ message: "Test route failed", error: err.message });
  }
});

// ================= MONGODB CONNECTION =================
const mongoUri = process.env.MONGO_URI;
if (!mongoUri) {
  console.error("❌ MONGO_URI is missing in .env");
  process.exit(1);
}

mongoose
  .connect(mongoUri, { dbName: "socialmedia" })
  .then(() => console.log("✅ MongoDB Connected Successfully"))
  .catch((err) => {
    console.error("❌ MongoDB Connection Error:", err);
    process.exit(1);
  });

// ================= START SERVER =================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🔥 Server running on port ${PORT}`));